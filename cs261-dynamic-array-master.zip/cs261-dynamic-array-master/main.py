# DynamicArray Scratchpad
# YOUR NAME
# Use this as a "scratchpad" to tinker with your data structure.

from dynamic_array import DynamicArray


# Example
ages = DynamicArray()
print(ages)
